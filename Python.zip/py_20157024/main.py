#variavel

QtdCoca = 150
QtdPepsi = 130
PrecoCoca =1.5
PrecoPepsi = 1.5

CustoLoja = 2.500

#ex1

totalPepsi = QtdPepsi * PrecoPepsi
print('Pepsi faturou o total de: ' + str(totalPepsi))

#ex2

totalCoca = QtdCoca * PrecoCoca
print('Coca faturou o total de: ' + str(totalCoca))

#ex3

TotalLucro = totalPepsi + totalCoca
print ('A loja faturou o total de: '+ str (TotalLucro))

#inputs/strings

bebida = input("Insira o código da bebida: ")
print("BAC" in bebida.upper())

#desafio

nome1 = input('Digite o nome e sobrenome do Declarado: \n')
nome2 = input('Digite o nome do Presente: \n')
evento = input('Digite o nome do evento: \n')
horario = input('Escolha entre: "Horario": \n')
gasto = input('Digite o valor gasto: formato: 00.00\n')

print('\nDeclaro para o ' + ' ' + nome1 + ' que o ' + nome2 + ' esteve presente no evento ' + evento + ' e gastou o valor de R$ ' + gasto + ' com a ' + horario+'.')





